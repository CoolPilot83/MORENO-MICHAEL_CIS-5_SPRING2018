/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Array1D.h
 * Author: rcc
 *
 * Created on May 31, 2018, 10:29 AM
 */

#ifndef ARRAY1D_H
#define ARRAY1D_H



#endif /* ARRAY1D_H */

