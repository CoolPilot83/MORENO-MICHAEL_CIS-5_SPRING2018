/* 
 * File:   main.cpp
 * Author: Michael D Moreno
 * Created on May 20, 2018, 11:30 AM
 * Purpose:  Uno Game for Project
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
void filDeck(char [], char);
void prtDeck(char [], char, char);

//Program Execution Begins Here
int main(int argc, char** argv) {
    //seeding the random number generator
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare all Variables Here
    const char MNDECK=108;      //Main Deck
    char deck[MNDECK];
    char HND=8;                 //Start Hand Amount
    char hand[HND];
    
    //Input or initialize values Here
    filDeck
    //Process/Calculations Here
    
    //Output Located Here
 

    //Exit
    return 0;
}

void filDeck(char [], char){
    
}