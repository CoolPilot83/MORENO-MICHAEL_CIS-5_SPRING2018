/* 
 * File:   main.cpp
 * Author: Michael Moreno
 * Created on March 1, 2018, 5:05 PM
 * Purpose: Sales Prediction of a Company: 
 *          The East Coast sales division of a 
 *          company generates 62 percent of total 
 *          sales. Based on that percentage, write 
 *          a program that will predict how much 
 *          the East Coast division will generate
 *          if the company has $4.6 million in sales
 *          this year. Display the result on the screen.
 */

// System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std; //namespace I/O steam library created

//User Libraries

//Global Constants
const float MILLN=1.0e6f;
const float PERCENT=100.0f;


//Math, Physics, Science, Conversions, 2-D Array Columns


// Function Prototypes


//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float eastSdp, totalS$, ttlEaSa;
    
    // Initial Variables
    totalS$ = 4.60f;
    eastSdp = 62.0f;
    
    // Map/Process Inputs to Outputs
    ttlEaSa=((totalS$)/PERCENT)*eastSdp;
    
    //Display Outputs
    cout<<"Total Company Sales = $"<<totalS$<<" Million"<<endl;
    cout<<"Percent of East Coast Sales = "<<eastSdp<<"%"<<endl;
    cout<<"Total East Coast Sales = $"<<ttlEaSa<<" Million"<<endl;
    
    //Exit program!
    return 0;
}

