/* 
 * File:   main.cpp
 * Author: Michael Moreno
 * Created on March 1, 2018, 5:05 PM
 * Purpose: Circuit Board Price:An electronics company sells circuit boards at a 40 percent profit. Write a program that
calculates the selling price of a circuit board that costs them $12.67 to produce. Display the
result on the screen.
 */

// System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std; //namespace I/O steam library created

//User Libraries

//Global Constants
const float PERCENT=100.0f;


//Math, Physics, Science, Conversions, 2-D Array Columns


// Function Prototypes


//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float costBd, profit, price;
    
    // Initial Variables
    profit = 40.0f;
    costBd = 12.67f;
    
    // Map/Process Inputs to Outputs
    price=((costBd/PERCENT)*profit)+costBd;
    
    //Display Outputs
    cout<<"Cost of Board:            $"<<costBd<<endl;
    cout<<"Profit:"<<"                +Profit"<<endl;
    cout<<"Total Cost with Profit:  "<<price<<endl;
            
    //Exit program!
    return 0;
}

