/* 
 * File:   main.cpp
 * Author: Michael Moreno
 * Created on March 2, 2018, 8:00 PM
 * Purpose: Miles per Gallon:
 *          A car holds 16 gallons of gasoline and can travel 350 miles before refueling. Write a program
that calculates the number of miles per gallon the car gets. Display the result on the screen.
 */

// System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std; //namespace I/O steam library created

//User Libraries

//Global Constants

const float PERCENT=100.0f;


//Math, Physics, Science, Conversions, 2-D Array Columns


// Function Prototypes


//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float tank, miTotal, mpg;
    
    // Initial Variables
    tank = 16.0f;
    miTotal = 350.0f;
    
    // Map/Process Inputs to Outputs
    mpg=miTotal/tank;
    
    
    //Display Outputs
    cout<<"Total Gallons of Gas in Tank: "<<tank<<" Gallons"<<endl;
    cout<<"Total Miles Traveled on One Tank: "<<miTotal<<" Miles"<<endl;
    cout<<"Miles per Gallon Average: "<<mpg<<" MPG"<<endl;
    
    
    
    
    //Exit program!
    return 0;
}

