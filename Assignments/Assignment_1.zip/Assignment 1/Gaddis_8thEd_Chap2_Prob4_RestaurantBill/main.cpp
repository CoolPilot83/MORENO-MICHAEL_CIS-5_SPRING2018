/* 
 * File:   main.cpp
 * Author: Michael Moreno
 * Created on March 2, 2018, 8:00 PM
 * Purpose: Restuarant Bill:
 *          Write a program that computes the tax and tip on a restaurant bill for a patron with a
$44.50 meal charge. The tax should be 6.75 percent of the meal cost. The tip should be 15
percent of the total after adding the tax. Display the meal cost, tax amount, tip amount, and
total bill on the screen.
 */

// System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std; //namespace I/O steam library created

//User Libraries

//Global Constants

const float PERCENT=100.0f;


//Math, Physics, Science, Conversions, 2-D Array Columns


// Function Prototypes


//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float intCost, taPCst, tatiCTo, taxPerc, tipPerc, taxDols, tipDols;
    
    // Initial Variables
    intCost = 44.50f;
    taxPerc = 6.75f;
    tipPerc = 15.0f;

    
    // Map/Process Inputs to Outputs

    taPCst=((intCost/PERCENT)*taxPerc)+intCost;
    tatiCTo=((taPCst/PERCENT)*tipPerc)+taPCst;
    taxDols=(intCost/PERCENT)*taxPerc;
    tipDols=(taPCst/PERCENT)*tipPerc;
    
    
    //Display Outputs
    cout<<"Cost of Meal: $"<<intCost<<endl;
    cout<<"Tax:  ("<<taxPerc<<"%) $ "<<taxDols<<endl;
    cout<<"Tip:   ("<<tipPerc<<"%)  $ "<<tipDols<<endl;
    cout<<"Total:        $"<<tatiCTo<<endl;
    
    
    
    
    //Exit program!
    return 0;
}

