/* 
 * File:   main.cpp
 * Author: Michael Moreno
 * Created on March 1, 2018, 5:05 PM
 * Purpose: Basketball Player Height: The star player of a high school basketball team is 73 inches tall. Write a program to compute
and display the height in feet / inches form.
Hint: Try using the modulus and integer divide operations.
 */

// System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std; //namespace I/O steam library created

//User Libraries

//Global Constants



//Math, Physics, Science, Conversions, 2-D Array Columns


// Function Prototypes


//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
  
    int ttlinch = 73, ttlfeet;
           
    ttlfeet = ttlinch/12.0;
    
    
    cout<<"Total Height in Inches: "<<ttlinch<<endl;
    cout<<"Total Height in Feet: "<<ttlfeet<<".08"<<endl;
    
    //Exit program!
    return 0;
}

