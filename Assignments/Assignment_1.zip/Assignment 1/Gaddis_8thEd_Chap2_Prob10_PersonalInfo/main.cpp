/* 
 * File:   main.cpp
 * Author: Michael Moreno
 * Created on March 3, 2018, 11:00 PM
 * Purpose: Personal Information: Write a program that displays the following information, each on a separate line:
Your name
Your address, with city, state, and zip code
Your telephone number
Your college major
Use only a single cout statement to display all of this information.
 */

// System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std; //namespace I/O steam library created

//User Libraries

//Global Constants

//Math, Physics, Science, Conversions, 2-D Array Columns

// Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    
    // Initial Variables

    // Map/Process Inputs to Outputs

    //Display Outputs
    cout<<"Name:           Michael D. Moreno\n"<<"Address:        26270 Parton Ct., Moreno Valley, CA, 92555\n"<<"Telephone:     (951) 807-1440\n"<<"College Major:  CyberSecurity";
    
    //Exit program!
    return 0;
}

