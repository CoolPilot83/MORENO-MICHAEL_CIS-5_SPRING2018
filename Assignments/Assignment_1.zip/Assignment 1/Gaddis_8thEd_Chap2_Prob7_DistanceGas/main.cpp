/* 
 * File:   main.cpp
 * Author: Michael Moreno
 * Created on March 3, 2018, 7:00 PM
 * Purpose: Distance per Tank of Gas:
 *          A car with a 20 gallon gas tank averages 21.5 miles per gallon when driven in town and
26.8 miles per gallon when driven on the highway. Write a program that calculates and
displays the distance the car can travel on one tank of gas when driven in town and when
driven on the highway.
 */

// System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std; //namespace I/O steam library created

//User Libraries

//Global Constants

const float PERCENT=100.0f;


//Math, Physics, Science, Conversions, 2-D Array Columns


// Function Prototypes


//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float tank, mpgtown, mpghiwy, posdtrT, posdtrH;
    
    // Initial Variables
    tank = 20.0f;
    mpgtown = 21.5f;
    mpghiwy = 26.8f;
    
    // Map/Process Inputs to Outputs
    posdtrT=tank*mpgtown;
    posdtrH=tank*mpghiwy;
    
    
    //Display Outputs
    cout<<"Total Gallons of Gas in Tank: "<<tank<<" Gallons"<<endl;
    cout<<"MPG in Town: "<<mpgtown<<" MPG"<<endl;
    cout<<"Total Miles in Town on One Tank: "<<posdtrT<<" Miles"<<endl;
    cout<<" "<<endl;
    cout<<"MPG in Highway: "<<mpghiwy<<" MPG"<<endl;
    cout<<"Total Miles on Highway on One Tank: "<<posdtrH<<" Miles"<<endl;
    
    
    
    //Exit program!
    return 0;
}

