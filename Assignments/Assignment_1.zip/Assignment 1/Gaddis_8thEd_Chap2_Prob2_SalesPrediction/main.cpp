/* 
 * File:   main.cpp
 * Author: Michael Moreno
 * Created on March 1, 2018, 7:05 PM
 * Purpose: Sales Tax of a purchase: 
 *          Write a program that computes the total 
 *          sales tax on a $52 purchase. Assume the state 
 *          sales tax is 4 percent and the county sales 
 *          tax is 2 percent. Display the purchase price, 
 *          state tax, county tax, and total tax amounts on the screen.
 */

// System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std; //namespace I/O steam library created

//User Libraries

//Global Constants
const float PERCENT=100.0f;


//Math, Physics, Science, Conversions, 2-D Array Columns

// Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float cost, //Cost of purchase ($52)              
          txStva, // Tax of State Variable 4%         
          txConva, // Tax of County Variable 2%        
          ttlSttx, // Total amount of state tax     
          ttlCttx, // Total amount of county tax        
          totalT$, // Total amount of tax (both)        
          ttalTp1, // 6% test 1                 
          ttalTp2; // 6% test 2                         
    
    // Initial Variables
    cost = 52.0f;
    txStva = 4.0f;
    txConva = 2.0f;
    
    ttalTp1 = 6.0f;
    
    // Map/Process Inputs to Outputs
    ttlSttx=(cost/PERCENT)*txStva;
    ttlCttx=(cost/PERCENT)*txConva;
    
    ttalTp2=(cost/PERCENT)*ttalTp1;
    
    //Display Outputs
    cout<<"Purchase Price = $"<<cost<<endl;
    cout<<"State Tax Percent = "<<txStva<<"% "<<endl;
    cout<<"State Tax in Dollars = $"<<ttlSttx<<endl;
    cout<<"County Tax Percent = "<<txConva<<"% "<<endl;
    cout<<"County Tax in Dollars = $"<<ttlCttx<<""<<endl;
    cout<<"Total Tax Percent = "<<"6%"<<endl;
    cout<<"Total Tax in Dollars = $"<<ttalTp2<<endl;
    cout<<"Total Purchase Price = $"<<(cost+ttalTp2)<<endl;
    
    //Exit program!
    return 0;
}

