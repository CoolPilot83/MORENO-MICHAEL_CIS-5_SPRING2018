/* 
 * File:   main.cpp
 * Author: Michael D Moreno
 * Created on May 4, 2018, 1:20 PM
 * Purpose:  Programming Project 5: Convert 24 hr format clock to 12 hr
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes
void input(int Ins);
void convert(int Convets);
void output(int Outs);
//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    char again, time;
    int hourIn, hourOut, minIn, minOut;
    //Initialize Variables
    char A="AM";
    char P="PM";
    //Process/Map inputs to outputs
    do{
        input;
        convert;
        output;
        
        cout<<endl<<"Would you like to continue Y/N"<<endl;
        cin>>again;
    }while(again=='Y'||again=='y');

    return 0;
}

void input(int Ins){
    cout<<"This program converts time inputs from a 24 Hour format to a 12 "
            "Hour "
            "format!"<<endl;
    cout<<"Please input your 24 Hour formatted time like so ( 14 25 )"<<endl;
    cin>>hourIn>>minIn;
}

void convert(int Convets){
    if(hourIn>25)void input;
    if(hourIn<13){
        hourOut=hourIn;
        time=A}
    if(hourIn>=13){
        hourOut=hourIn-12;
        time=P}
    else void input;
    
    minIn=minOut;
}

void output(int Outs){
    cout<<"The input you have given is :"<<hourIn<<':'<<minIn<<endl;
    cout<<"The Converted Time is       :"<<hourOut<<':'<<minOut<<" "<<time
            <<endl;
}