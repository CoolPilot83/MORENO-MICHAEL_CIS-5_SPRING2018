/* 
 * File:   main.cpp
 * Author: Michael D. Moreno
 * Created on March 15th, 2018, 1:50 AM
 * Purpose:  Gaddis Programming Project 13, Personnal Best
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float namefrt, namelas, vaudat1, vaudat2, vaudat3, vauhei1, vauhei2, vauhei3, pos1, pos2, pos3;
    
    cout<<"This program calculates the personal best vaulter heights in order from highest to lowest!"<<endl;
    cout<<"First input your first name"<<endl;
    cin>>namefrt>>endl;
    cout<<"Now input your last name"<<endl;
    cin>>namelas>>endl;
    cout<<"Next enter your first vault height followed by the date with a space"<<endl;
    cin>>vauhei1>>vaudat1>>endl;
    cout<<"Enter your second vault height followed by the date with a space"<<endl;
    cin>>vauhei2>>vaudat2>>endl;
    cout<<"Finally, your last vault height followed by the date with a space"<<endl;
    cin>>vauhei3>>vaudat3>>endl;
    
    if(vauhei1<vauhei2)
        {
        set(vauhei1=pos1)
        }
    if(vauhei1<vauhei3)
    {   
        set(vauhei1=pos1)//Unfinished
    }
   
    //Exit stage right!
    return 0;
}