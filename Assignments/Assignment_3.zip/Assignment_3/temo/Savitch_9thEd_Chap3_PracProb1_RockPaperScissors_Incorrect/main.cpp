/* 
 * File:   main.cpp
 * Author: Michael D Moreno
 * Created on March 18th, 2018, 9:10 PM
 * Purpose:  savitch Chap3 Practice Problem 1: Rock, Paper, Scissors
 */

//System Libraries
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    float plyr1,plyr2, R, P, S;
    
    //Initialize Variables
    plyr1=P,S,R;
    plyr1=rand();
    
    
  
   
    
    
    //Output data
    
    //Exit stage right!
    return 0;
}