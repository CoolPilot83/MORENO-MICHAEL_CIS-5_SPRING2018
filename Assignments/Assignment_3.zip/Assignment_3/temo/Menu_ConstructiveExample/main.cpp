/* 
 * File:   main.cpp
 * Author: Michael D. Moreno
 * Created on March 22, 2018, 10:40 PM
 * Purpose:  Menu for Assignment 3
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    char choice; 
    
    //Display Menu
    cout<<"Choose from the following Menu"<<endl;
    cout<<"Type 1 for Rock, Paper, Scissors!"<<endl;
    cout<<"Type 2 for Astrology Horoscope"<<endl;
    cout<<"Type 3 for Fibonaci's Green Crud"<<endl;
    cout<<"Type 4 for 100 Prime Ints"<<endl;
    cin>>choice;
       
    //Process/Calculations Here
    if(choice>='1'&&choice<='4'){
        switch(choice){
            case'1':{
                cout<<"Rock, Paper, Scissors!"<<endl;
                srand(static_cast<unsigned int>(time(0)));
                //Declare Variables
                char plyr1,plyr2;
                //Initialize Variables
                plyr1=rand()%3+'R';
                plyr1=plyr1>'S'?'P':plyr1;
                plyr2=rand()%3+'R'; 
                plyr2=plyr2>'S'?'P':plyr2;
                //Players choice
                cout<<"Rock Paper Scissors Game"<<endl;
                cout<<"Player 1 = "<<plyr1<<endl;
                cout<<"Player 2 = "<<plyr2<<endl;
                //Winning or Not
                if(plyr1==plyr2){
                    cout<<"The game is a tie"<<endl;
                }else if(plyr1=='P'){
                    if(plyr2=='S'){
                        cout<<"Player 2 wins"<<endl;
                }else{
                        cout<<"Player 1 wins"<<endl;
                }
                }else if(plyr1=='S'){
                    if(plyr2=='R'){
                        cout<<"Player 2 wins"<<endl;
                }else{
                        cout<<"Player 1 wins"<<endl;
                }
                }else{
                    if(plyr2=='P'){
                        cout<<"Player 2 wins"<<endl;
                    }else{
                        cout<<"Player 1 wins"<<endl;
                    }
                }
                break;
            }
            case'2':{
                int bdayday, bdaymon;
                //Initialize Variables
    
                //Process/Map inputs to outputs
                cout<<"This program will determine your horoscope sign from your birthday!"<<endl;
                do{
                    cout<<"Type the month of your birthday using 1-12"<<endl;
                    cin>>setw(2)>>bdaymon;
                }while(bdaymon<1||bdaymon>12);//Birthday Input (Month)
                    if(bdaymon==1, 3, 5, 7, 8, 10, 12)//Incomplete Day limit for months
                        {do{
                            cout<<"Now type the day of your birthday"<<endl;
                            cin>>setw(2)>>bdayday;
                        }while(bdayday<1||bdayday>31);}//Birthday Input (Day)
                if((bdaymon==1&&bdayday>= 20)||(bdaymon==2&&bdayday<=18))//Begining of Range Parameters for horoscope signs
                        {cout<<"Your horoscope sign is Aquarius"<<endl;}
                    else if((bdaymon==2&&bdayday>=19)||(bdaymon==3&&bdayday<=20))
                        {cout<<"Your horoscope sign is Pisces"<<endl;}
                    else if((bdaymon==3&&bdayday>=21)||(bdaymon==4&&bdayday<=19))
                        {cout<<"Your horoscope sign is Aries"<<endl;}
                    else if((bdaymon==4&&bdayday>=20)||(bdaymon==5&&bdayday<=20))
                        {cout<<"Your horoscope sign is Taurus"<<endl;}
                    else if((bdaymon==5&&bdayday>=21)||(bdaymon==6&&bdayday<=20))
                        {cout<<"Your horoscope sign is Gemini"<<endl;}
                    else if((bdaymon==6&&bdayday>=21)||(bdaymon==7&&bdayday<=22))
                        {cout<<"Your horoscope sign is Cancer"<<endl;}
                    else if((bdaymon==7&&bdayday<=23)||(bdaymon==8&&bdayday<=22))
                        {cout<<"Your horoscope sign is Leo"<<endl;}
                    else if((bdaymon==8&&bdayday>=23)||( bdaymon==9&&bdayday<=22))
                        {cout<<"Your horoscope sign is Virgo"<<endl;}
                    else if((bdaymon==9&&bdayday>=23)||(bdaymon==10&&bdayday<=22))
                        {cout<<"Your horoscope sign is Libra"<<endl;}
                    else if((bdaymon==10&&bdayday>=23)||(bdaymon==11&&bdayday<=21))
                        {cout<<"Your horoscope sign is Scorpio"<<endl;}
                    else if((bdaymon==11&&bdayday>=22)||(bdaymon==12&&bdayday<=21))
                        {cout<<"Your horoscope sign is Sagittarius"<<endl;}
                    else if((bdaymon==12&&bdayday>=22)||(bdaymon==1&&bdayday<=19))
                        {cout<<"Your horoscope sign is Capricorn"<<endl;}  //End of Range
                    else {cout<<"Invalid Birthday Input"<<endl;} //Invalid range if ever meet
                break;
            }
            case'3':{
                //Declare Variables
    int fn,fnm1,fnm2,intCrud,days;
    
    //Initialize Variables
    fnm2=1;
    fnm1=1;
    intCrud=10;
    days=0;
    
    //Printout the first 2 in the sequence
    cout<<"Fibonacci Sequence with Green Crud"<<endl;
    cout<<"On day "<<setw(3)<<days
            <<" there is "<<setw(4)<<fnm2*intCrud
            <<" lbs of crud"<<endl;
    days+=5;
    cout<<"On day "<<setw(3)<<days
            <<" there is "<<setw(4)<<fnm1*intCrud
            <<" lbs of crud"<<endl;
    
    //Calculate 3rd element in sequence
    fn=fnm1+fnm2;
    fnm2=fnm1;
    fnm1=fn;
    days+=5;
    cout<<"On day "<<setw(3)<<days
            <<" there is "<<setw(4)<<fn*intCrud
            <<" lbs of crud"<<endl;
    
    //Calculate 4th element in sequence
    fn=fnm1+fnm2;
    fnm2=fnm1;
    fnm1=fn;
    days+=5;
    cout<<"On day "<<setw(3)<<days
            <<" there is "<<setw(4)<<fn*intCrud
            <<" lbs of crud"<<endl;
    
    //Calculate 5th element in sequence
    fn=fnm1+fnm2;
    fnm2=fnm1;
    fnm1=fn;
    days+=5;
    cout<<"On day "<<setw(3)<<days
            <<" there is "<<setw(4)<<fn*intCrud
            <<" lbs of crud"<<endl;
 
    //Calculate 6th element in sequence
    fn=fnm1+fnm2;
    fnm2=fnm1;
    fnm1=fn;
    days+=5;
    cout<<"On day "<<setw(3)<<days
            <<" there is "<<setw(4)<<fn*intCrud
            <<" lbs of crud"<<endl;
    
    //Calculate 7th element in sequence
    fn=fnm1+fnm2;
    fnm2=fnm1;
    fnm1=fn;
    days+=5;
    cout<<"On day "<<setw(3)<<days
            <<" there is "<<setw(4)<<fn*intCrud
            <<" lbs of crud"<<endl;
    
    //Calculate 8th element in sequence
    fn=fnm1+fnm2;
    fnm2=fnm1;
    fnm1=fn;
    days+=5;
    cout<<"On day "<<setw(3)<<days
            <<" there is "<<setw(4)<<fn*intCrud
            <<" lbs of crud"<<endl;
    
    //Calculate 9th element in sequence
    fn=fnm1+fnm2;
    fnm2=fnm1;
    fnm1=fn;
    days+=5;
    cout<<"On day "<<setw(3)<<days
            <<" there is "<<setw(4)<<fn*intCrud
            <<" lbs of crud"<<endl;
                break;
            }
            case'4':{
                //Set rand number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare all Variables Here
    char num2Tst; // 2-100
    bool prime; //Determine if num2tst is prime
    
    num2Tst=rand()%99+2; // [2,100]
    
    //Process/Calculations Here
    prime=num2Tst==2?true&&prime:num2Tst%2;
    prime=num2Tst==3?true&&prime:prime&&num2Tst%3;
    prime=num2Tst==5?true&&prime:prime&&num2Tst%5;
    prime=num2Tst==7?true&&prime:prime&&num2Tst%7;
    //Output Located Here
    cout<<static_cast<int>(num2Tst)<<" is "<<(prime?"Prime":"Not Prime")<<endl;
                break;
            }
        }
    }else{
        cout<<"Exiting Menu"<<endl;
    }
    //Output Located Here
   

    //Exit
    return 0;
}

